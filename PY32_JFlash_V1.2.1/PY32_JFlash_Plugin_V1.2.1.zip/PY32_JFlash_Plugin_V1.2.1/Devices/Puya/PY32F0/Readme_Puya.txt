The Puya devices support comes without any warranty and support from Puya Semiconductor. Support is provided via Puya only.
For support, please contact: fae@puyasemi.com