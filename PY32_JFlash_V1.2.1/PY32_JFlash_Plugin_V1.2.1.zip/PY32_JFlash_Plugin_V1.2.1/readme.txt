将此文件夹中的所有文件全部拷贝至JFLASH安装目录。如：
C:\Program Files\SEGGER\Flasher
C:\Program Files\SEGGER\JLink

* V1.2.1 - 06/27/2023
=====================
    + Add PY32C611, PY32C610, PY32M030, PY32F040, PY32M070, PY32F002B, PY32L020, PY32F031, PY32F303

* V1.2.0 - 03/21/2023
=====================
    + Add PY32F071
        

* V1.1.0 - 01/05/2023
=====================
    + Add PY32F002, PY32F072, PY32F403

   
* V1.0.0 - 06/02/2022 
====================
    Created.